<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
		<title>Equipamientos JDK | <?php echo $__env->yieldContent('title'); ?></title>
	</head>
	<body>
		<h1 class="text-3xl font-bold text-red-600 underline">Equipamientos JDK</h1>
		<h1 class="text-3xl font-bold text-red-600 underline">Equipamientos JDK</h1>
	</body>
</html><?php /**PATH C:\laragon\www\equipamientosjdk\resources\views/welcome.blade.php ENDPATH**/ ?>