<?php $__env->startSection('title', 'Bienvenido'); ?>
<?php $__env->startSection('content'); ?>
	<div class="bg-white">
		<div class="relative pb-32 bg-gray-800">
			<div class="absolute inset-0">
				<img class="w-full h-full object-cover" src="<?php echo e(asset('src/assets/imgs/banners/banner-hero.jpg')); ?>" alt="Banner Hero">
				<div class="absolute inset-0 bg-gray-800 mix-blend-multiply" aria-hidden="true"></div>
			</div>
			<div class="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
				<h1 class="text-4xl font-extrabold tracking-tight text-white md:text-5xl lg:text-6xl">Servicios</h1>
				<p class="mt-6 max-w-3xl text-xl text-gray-300">Ofrezco servicios varios en electronica, soporte técnico/reparaciones en general, me importa la opinion y la satisfaction
					del cliente con mi trabajo y es por eso que me esfuerzo en mantener una línea directa con el cliente asesorándolo en sus consultas.
				</p>
			</div>
		</div>
		<section class="-mt-32 max-w-7xl mx-auto relative z-10 pb-32 px-4 sm:px-6 lg:px-8" aria-labelledby="contact-heading">
			<h2 class="sr-only" id="contact-heading">Contact us</h2>
			<div class="grid grid-cols-1 gap-y-20 lg:grid-cols-3 lg:gap-y-0 lg:gap-x-8">
				<div class="flex flex-col bg-white rounded-2xl shadow-xl">
					<div class="flex-1 relative pt-16 px-6 pb-8 md:px-8">
						<div class="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
							<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
								<path stroke-linecap="round" stroke-linejoin="round"
								      d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
							</svg>
						</div>
						<h3 class="text-xl font-medium text-gray-900">Electronica</h3>
						<p class="mt-4 text-base text-gray-500">Varius facilisi mauris sed sit. Non sed et duis dui leo, vulputate id malesuada non. Cras aliquet purus dui laoreet diam sed
							lacus, fames.
						</p>
					</div>
				</div>
				<div class="flex flex-col bg-white rounded-2xl shadow-xl">
					<div class="flex-1 relative pt-16 px-6 pb-8 md:px-8">
						<div class="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
							<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
								<path stroke-linecap="round" stroke-linejoin="round"
								      d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
								<path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
							</svg>
						</div>
						<h3 class="text-xl font-medium text-gray-900">Soporte técnico</h3>
						<p class="mt-4 text-base text-gray-500">Varius facilisi mauris sed sit. Non sed et duis dui leo, vulputate id malesuada non. Cras aliquet purus dui laoreet diam sed
							lacus, fames.
						</p>
					</div>
				</div>
				<div class="flex flex-col bg-white rounded-2xl shadow-xl">
					<div class="flex-1 relative pt-16 px-6 pb-8 md:px-8">
						<div class="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
							<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
								<path stroke-linecap="round" stroke-linejoin="round"
								      d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
							</svg>
						</div>
						<h3 class="text-xl font-medium text-gray-900">Presupuesto sin cargo</h3>
						<p class="mt-4 text-base text-gray-500">Varius facilisi mauris sed sit. Non sed et duis dui leo, vulputate id malesuada non. Cras aliquet purus dui laoreet diam sed
							lacus, fames.
						</p>
					</div>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
	<script>
		const closeMenu = document.getElementById('close-menu');
		const openMenu  = document.getElementById('open-menu');
		const menuMob   = document.getElementById('menu-mob');
		
		closeMenu.addEventListener('click', () => {
			menuMob.classList.replace('md:hidden', 'hidden');
		});
		
		openMenu.addEventListener('click', () => {
			menuMob.classList.replace('hidden', 'md:hidden');
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.layout-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\equipamientosjdk\resources\views/sections/home.blade.php ENDPATH**/ ?>